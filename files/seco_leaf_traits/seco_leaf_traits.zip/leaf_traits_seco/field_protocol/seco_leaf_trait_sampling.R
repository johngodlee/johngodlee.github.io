# SECO: Sample dominant species across plots for traits
# John L. Godlee (john.godlee@ed.ac.uk)
# 2022-04-27

# Import example data
dat <- read.csv("./kilwa_fil.csv")

# Sample dominant species within a plot up to proportion of total abundance
#
# @param x dataframe with individuals from a single plot
# @param species column name of species names
# @param abundance column name of measure of abundance
# @param per minimum proportion of total abundance to sample up to
#
# @return character vector with names of dominant species
# 
domSpecies <- function(x, species, abundance, per) {

  # Split data by species name
  x_split <- split(x, x[[species]])

  # Calculate total abundance 
  ab_total <- sum(x[[abundance]])

  # Calculate minimum proportion of total abundance 
  ab_per <- ab_total * per

  # For each species, find abundance
  # sort from most to least abundant
  # Sequentially add species to sample until minimum proportion surpassed
  ab_cum <- cumsum(
    sort(
      sapply(x_split, function(y) {
        sum(y[[abundance]])
      }), 
      decreasing = TRUE)
    )
    
  # Extract names of dominant species to sample
  if (length(ab_cum) > 1) {
    out <- names(ab_cum)[ab_cum <= ab_per]
  } else {
    out <- names(ab_cum)
  }
  
  # Return
  return(out)
}

# Calculate rolling mean over a defined window
#
# @param x numeric vector
# @param win window length
#
# @return numeric vector with rolling means
# 
rollmean <- function(x, win) {
  n <- length(x)
  y <- x[win:n] - x[c(1, 1:(n-win))]
  y[1] <- sum(x[1:win])
  return(cumsum(y) / win)
}

# Sample individuals across a range of tree sizes 
#
# @param x dataframe of individuals
# @param abundance column name of measure of size
# @param n number of individuals to sample
#
# @return subset of `x` with sampled individuals
# 
rangeSample <- function(x, abundance, n) {
  # Find quantiles 
  qu <- as.vector((quantile(range(x[[abundance]], na.rm = TRUE), 
    seq(0,1,1/n))))
  
  # Get midpoint between quantiles
  qu_mid <- rev(rollmean(qu, 2))
  
  # For each quantile midpoint, find closest individual not already sampled
  ind <- vector()
  x <- as.data.frame(x)
  x_fil <- x
  
  for (i in seq_along(qu_mid)) {
    if (nrow(x_fil) > 0) {
      ind[length(ind)+1] <- rownames(x_fil)[which(abs(x_fil[[abundance]]-qu_mid[i]) == 
          min(abs(x_fil[[abundance]]-qu_mid[i])))[1]]
      x_fil <- x_fil[!rownames(x_fil) %in% ind,]
    }
  }
 
  return(x[ind,])
}

# Sample individuals across sizes from dominant species across multiple plots
#
# @param dataframe of individuals
# @param plot_id column name of plot IDs
# @param species column name of species names
# @param abundance column name of measure of abundance
# @param per minimum proportion of total abundance to sample up to
# @param n number of individuals to sample from each dominant species
#
traitSample <- function(x, plot_id, species, abundance, per, n) {
  x_split <- split(x, x[[plot_id]])
  
  samples <- do.call(rbind, lapply(x_split, function(y) {
    dom_sp <- domSpecies(y, species, abundance, per)
    
    y_split <- split(y, y[[species]])[dom_sp]
    
    do.call(rbind, lapply(y_split, function(z) {
      rangeSample(z, abundance, n)
    }))
  }))
  
  rownames(samples) <- NULL
  
  return(samples)
}

# Run wrapper function with example data
traitSample(dat, "plot_id", "species", "ba", 0.8, 5)
