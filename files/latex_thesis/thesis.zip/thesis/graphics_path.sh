#!/usr/bin/env bash

path="./chapters/*/img"

echo -n "\\graphicspath{{img/}" > graphics_path.tex

for i in $path; do
	echo -n "\{$i/\}" >> graphics_path.tex
done

echo \} >> graphics_path.tex
