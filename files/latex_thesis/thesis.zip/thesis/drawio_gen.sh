#!/usr/bin/env sh

/Applications/draw.io.app/Contents/MacOS/./draw.io --crop -x -o struc.pdf struc.drawio
